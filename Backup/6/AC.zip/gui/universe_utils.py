﻿import pandas as pd
import os

def carregar_sp500(cache=True):
    url = "https://datahub.io/core/s-and-p-500-companies/r/constituents.csv"
    cache_file = "cache_sp500.csv"
    if cache and os.path.isfile(cache_file):
        try:
            return sorted(list(pd.read_csv(cache_file)["Symbol"].unique()))
        except Exception: pass
    try:
        tabela = pd.read_csv(url)
        tabela.to_csv(cache_file, index=False)
        return sorted(list(tabela["Symbol"].unique()))
    except Exception as e:
        print(f"[ERRO] Não foi possível carregar o S&P500 online: {e}")
        return []

def carregar_nasdaq100(cache=True):
    url = "https://en.wikipedia.org/wiki/NASDAQ-100"
    cache_file = "cache_nasdaq100.csv"
    if cache and os.path.isfile(cache_file):
        try:
            return sorted(list(pd.read_csv(cache_file)["Ticker"].unique()))
        except Exception: pass
    try:
        dfs = pd.read_html(url, header=0)
        tabela = next(df for df in dfs if "Ticker" in df.columns)
        tabela["Ticker"].to_frame().to_csv(cache_file, index=False)
        return sorted(list(tabela["Ticker"].str.replace(r"\.", "-", regex=True).unique()))
    except Exception as e:
        print(f"[ERRO] Não foi possível carregar o NASDAQ-100 online: {e}")
        return []

def carregar_psi20(cache=True):
    url = "https://en.wikipedia.org/wiki/PSI-20"
    cache_file = "cache_psi20.csv"
    if cache and os.path.isfile(cache_file):
        try:
            return sorted(list(pd.read_csv(cache_file)["Ticker"].unique()))
        except Exception: pass
    try:
        dfs = pd.read_html(url, header=0)
        tabela = next(df for df in dfs if any("Ticker" in col or "Símbolo" in col for col in df.columns))
        col = [c for c in tabela.columns if "Ticker" in c or "Símbolo" in c][0]
        pd.DataFrame({ "Ticker": tabela[col] }).to_csv(cache_file, index=False)
        return sorted([t.split()[0].replace('.', '-').upper() for t in tabela[col].unique()])
    except Exception as e:
        print(f"[ERRO] Não foi possível carregar o PSI20 online: {e}")
        return []

def carregar_euronext100(cache=True):
    url = "https://en.wikipedia.org/wiki/Euronext_100"
    cache_file = "cache_euronext100.csv"
    if cache and os.path.isfile(cache_file):
        try:
            return sorted(list(pd.read_csv(cache_file)["Ticker"].unique()))
        except Exception: pass
    try:
        dfs = pd.read_html(url, header=0)
        tabela = next(df for df in dfs if any("Ticker" in col or "Symbol" in col for col in df.columns))
        col = [c for c in tabela.columns if "Ticker" in c or "Symbol" in c][0]
        pd.DataFrame({ "Ticker": tabela[col] }).to_csv(cache_file, index=False)
        return sorted([t.split()[0].replace('.', '-').upper() for t in tabela[col].unique()])
    except Exception as e:
        print(f"[ERRO] Não foi possível carregar o Euronext 100 online: {e}")
        return []

def carregar_eurostoxx50(cache=True):
    url = "https://en.wikipedia.org/wiki/EURO_STOXX_50"
    cache_file = "cache_eurostoxx50.csv"
    if cache and os.path.isfile(cache_file):
        try:
            return sorted(list(pd.read_csv(cache_file)["Ticker"].unique()))
        except Exception: pass
    try:
        dfs = pd.read_html(url, header=0)
        tabela = next(df for df in dfs if any("Ticker" in col or "Symbol" in col for col in df.columns))
        col = [c for c in tabela.columns if "Ticker" in c or "Symbol" in c][0]
        pd.DataFrame({ "Ticker": tabela[col] }).to_csv(cache_file, index=False)
        return sorted([t.split()[0].replace('.', '-').upper() for t in tabela[col].unique()])
    except Exception as e:
        print(f"[ERRO] Não foi possível carregar o Euro Stoxx 50 online: {e}")
        return []

def carregar_nyse(cache=True):
    url = "https://en.wikipedia.org/wiki/List_of_S%26P_100_companies"
    cache_file = "cache_nyse.csv"
    if cache and os.path.isfile(cache_file):
        try:
            return sorted(list(pd.read_csv(cache_file)["Symbol"].unique()))
        except Exception: pass
    try:
        dfs = pd.read_html(url, header=0)
        tabela = dfs[0]
        tabela[["Symbol"]].to_csv(cache_file, index=False)
        return sorted(list(tabela["Symbol"].unique()))
    except Exception as e:
        print(f"[ERRO] Não foi possível carregar a NYSE (S&P100) online: {e}")
        return []

def carregar_tickers_ficheiro(ficheiro="tickers_custom.txt"):
    try:
        with open(ficheiro, "r") as f:
            return [linha.strip().upper() for linha in f if linha.strip()]
    except Exception as e:
        print(f"[ERRO] Falha ao carregar ficheiro '{ficheiro}': {e}")
        return []

def guardar_tickers_ficheiro(tickers, ficheiro="tickers_custom.txt"):
    try:
        with open(ficheiro, "w") as f:
            for t in tickers:
                f.write(f"{t}\n")
    except Exception as e:
        print(f"[ERRO] Falha ao guardar ficheiro '{ficheiro}': {e}")

UNIVERSE_FUNCS = {
    "S&P500": carregar_sp500,
    "NASDAQ100": carregar_nasdaq100,
    "PSI20": carregar_psi20,
    "Euronext100": carregar_euronext100,
    "EuroStoxx50": carregar_eurostoxx50,
    "NYSE": carregar_nyse,
    "Personalizado": carregar_tickers_ficheiro,
}
